<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="UTF-8">
    </head>
    <body>
        <?php
        $trovato = false;
        $a = $_GET['nome'];
        $squadre = array("Inter" => array("icardi", "swagvic"), "Milan" => array("bonucci", "donnarumma"));
        foreach ($squadre as $chiave => $squadra) {
            foreach ($squadra as $giocatore) {
                if ($giocatore == $a) {
                    $trovato = true;
                    echo('<select>');
                    for ($j = 0; $j < 10; $j++) {
                        echo("<option>$a gioca con $chiave</option>");
                    }
                    echo('</select>');
                }
            }
        }
        if (!$trovato) {
            echo("$a non risulta nell'archivio");
        }
        ?>
    </body>
</html>