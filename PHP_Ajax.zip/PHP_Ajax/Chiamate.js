function richiestaAjax() {
    str = document.getElementById("nec").value;
    var xmlHttp = getXMLhttp();

    xmlHttp.onreadystatechange = function () {
        if (xmlHttp.readyState == 4 && this.status == 200) {
            HandleResponse(xmlHttp.responseText);
        }
    }

    xmlHttp.open("GET", "mioPrimo.php?nome=" + str, true);
    xmlHttp.send(null);
}

function getXMLhttp() {
    var xmlHttp;
    try {
        xmlHttp = new XMLHttpRequest();
    } catch (e) {
        alert("Browser non supportato");
        return false;
    }
    return xmlHttp;
}

function HandleResponse(response) {
    document.getElementById("testo").innerHTML = response;
}